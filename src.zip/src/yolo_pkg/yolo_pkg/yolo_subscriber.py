import rclpy
from rclpy.node import Node
from std_msgs.msg import String

class DataSubscriber(Node):
    def __init__(self):
        super().__init__('data_subscriber')
        self.subscription_ = self.create_subscription(String, 'yolo_data', self.data_callback, 10)
    
    def data_callback(self, msg):
        data = msg.data
        print(data)
        # 여기에 수신한 'data'를 처리하는 코드를 작성하세요
        # 예: 데이터를 분석하거나 로봇 동작을 수행하는 등의 작업

def main(args=None):
    rclpy.init(args=args)
    data_subscriber = DataSubscriber()
    rclpy.spin(data_subscriber)
    data_subscriber.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
