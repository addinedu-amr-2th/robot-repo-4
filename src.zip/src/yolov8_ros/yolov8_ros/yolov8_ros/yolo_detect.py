from ultralytics import YOLO
from PIL import Image
import cv2
import numpy as np

camera_index = 2
# 카메라 열기
cap = cv2.VideoCapture(camera_index)

model = YOLO("/home/yun/robot_ws/yolov8m.pt")
#model = YOLO("yolov8n.pt", save_dir="/path/to/save_dir")


font = cv2.FONT_HERSHEY_SIMPLEX
font_scale = 1
color = (0, 0, 255) # BGR color format
thickness = 2
data = []

def main():
   
    # 카메라가 정상적으로 열렸는지 확인
    if not cap.isOpened():
        print("카메라를 열 수 없습니다.")
        return
    
    while True:
        # 프레임 읽기
        ret, image = cap.read()

        result = model(image)[0]
        # Get the bounding box coordinates of the detected person
        boxes = result.boxes.boxes
        boxes_conf = result.boxes
        boxes_list = boxes.tolist()
        #print(boxes_list)
        if len(boxes_list) != 0:
            box1 = boxes[0]
            # for box in boxes :
            x1, y1, x2, y2, score, idx = box1
            # Draw a rectangle around the detected person
            cv2.rectangle(image, (int(x1), int(y1)), (int(x2), int(y2)), (0, 255, 0), 2)
            # Add the text to the image
            cv2.putText(image, result.names[int(idx)], (int(x1), int(y1)-10), font, font_scale, color, thickness)
            #print(box1)
            #print(score.tolist())
            x_center, y_center, diagnal = (x1+x2)/2, (y1+y2)/2, (x1-x2)**2+(y1-y2)**2
            data = [x_center.tolist(), y_center.tolist(), np.sqrt(diagnal.tolist()), score.tolist()]
            print(data)
            
        else:
            cv2.imshow('img',image)
        
        cv2.imshow('img', image)
        # 프레임 읽기에 실패하면 종료
        if not ret:
            break
        
        # 'q' 키를 누르면 종료
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    
    # 리소스 해제
    cap.release()
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main()
