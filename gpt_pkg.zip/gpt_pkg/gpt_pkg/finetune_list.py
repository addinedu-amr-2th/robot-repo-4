import openai

model_id = "ft-lM5fEXE1IEW8S0sPH4D7xAkd"
openai.api_key = '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'

model_info = openai.FineTune.retrieve(model_id)

print(model_info)
