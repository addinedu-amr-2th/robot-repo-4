import openai
import os

openai.api_key = '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'
answer = openai.Completion.create(
    model='curie:ft-personal-2023-06-20-06-58-48',
    prompt="Let's play foot ball, Do you know where it is? \n\n###\n\n",
    stop="END"
    )

print(answer["choices"][0]["text"])
