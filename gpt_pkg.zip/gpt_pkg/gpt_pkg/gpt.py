import openai
import os
import rclpy
from rclpy.node import Node
from std_msgs.msg import String

openai.api_key = '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'

class TextSubscriber(Node):
    def __init__(self):
        super().__init__('text_subscriber')
        self.subscription_ = self.create_subscription(
            String,
            'stt_text',
            self.receive_text,
            10
        )
        self.subscription_

        #publisher
        self.publisher_ = self.create_publisher(String, 'gpt_cmd', 10)
        self.gpt_cmd = String()

    def receive_text(self, msg):
        self.get_logger().info('Received: "%s"' % msg.data)
        answer = openai.Completion.create(model='curie:ft-personal-2023-06-20-06-58-48',
                                          prompt=f"{msg.data} \n\n###\n\n",
                                          stop="END"
                                          )
        completion = answer["choices"][0]["text"]
        self.gpt_cmd.data = completion
        self.publisher_.publish(self.gpt_cmd)
        print(completion)

def main(args=None):
    rclpy.init(args=args)
    subscriber = TextSubscriber()
    rclpy.spin(subscriber)
    subscriber.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()


